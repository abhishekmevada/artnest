const {
  Artwork,
  User,
  ArtistProfile,
  NewsletterSubscriber,
} = require("../../db/db");
const { validateEmail } = require("../validators/auth.validator");

const getAllArtwork = async (req, res) => {
  try {
    const getAllArtwork = await Artwork.find().populate("artist_id", "name");

    res.status(200).json({ message: "All Artwork", getAllArtwork });
  } catch (error) {
    return res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const getAllArtist = async (req, res) => {
  try {
    // 1. Get all artists
    const artists = await User.find({ role: "artist" }).select("name email");

    // 2. Get each artist's profile and top 3 artworks
    const artistProfiles = await Promise.all(
      artists.map(async (artist) => {
        // Get artist profile
        const profile = await ArtistProfile.findOne({
          user_id: artist._id,
        });

        // Get top 3 published artworks
        const artworks = await Artwork.find({
          artist_id: artist._id,
          status: "published",
        })
          .select("artworkId title image")
          .sort({ createdAt: -1 })
          .limit(3);

        return {
          ...artist.toObject(),
          artistProfile: profile,
          topArtworks: artworks.map((artwork) => ({
            artworkId: artwork.artworkId,
            title: artwork.title,
            image: artwork.image.map((img) => ({
              url: img.url,
              publicId: img.publicId,
            })),
          })),
        };
      }),
    );

    return res.status(200).json({
      success: true,
      message: "Artists fetched successfully",
      totalArtists: artistProfiles.length,
      artists: artistProfiles,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const newsletterSub = async (req, res) => {
  const { email } = req.body;

  try {
    const emailError = validateEmail(email);

    if (emailError) {
      return res.status(400).json({ message: emailError });
    }

    const checkExistemail = await NewsletterSubscriber.findOne({ email });

    if (checkExistemail) {
      return res.status(400).json({ message: "email already exist" });
    }

    const newSub = new NewsletterSubscriber({
      email,
    });
    await newSub.save();
    res.status(200).json({ message: "Subscribe Successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getAllArtwork, getAllArtist, newsletterSub };
