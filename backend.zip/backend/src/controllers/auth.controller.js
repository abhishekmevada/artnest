const {
  validateEmail,
  validateName,
  validatePassword,
  validateStudioName,
} = require("../validators/auth.validator");
const { OAuth2Client } = require("google-auth-library");
const bcrypt = require("bcrypt");
const { User, ArtistProfile } = require("../../db/db");
const jsonwebtoken = require("jsonwebtoken");
const { verifyGoogleToken } = require("../services/googleAuthService");
const tokenService = require("../services/token.service");

const jwt = process.env.jwt;

const googleBuyer = async (req, res) => {
  try {
    const { idToken } = req.body || {};

    if (!idToken || typeof idToken !== "string") {
      return res.status(400).json({
        message: "A valid idToken is required",
      });
    }

    let googleUser;

    try {
      googleUser = await verifyGoogleToken(idToken);
    } catch (error) {
      // Inspect the actual verification failure in your backend terminal.
      console.error("Google token verification failed:", error.message);

      return res.status(401).json({
        message: "Google token verification failed",
      });
    }

    const { googleId, email, name } = googleUser;

    let user = await User.findOne({
      $or: [{ googleId }, { email }],
    });

    let isNewUser = false;

    if (user) {
      if (user.status === "block") {
        return res.status(403).json({
          message: "Your account is blocked",
        });
      }

      if (user.role !== "buyer") {
        return res.status(409).json({
          message: `This email is already registered with role: ${user.role}`,
        });
      }

      if (user.googleId && user.googleId !== googleId) {
        return res.status(409).json({
          message: "This account is linked to a different Google account",
        });
      }

      if (!user.googleId) {
        user.googleId = googleId;
        user.authProvider = "google";
        await user.save();
      }
    } else {
      user = new User({
        name,
        email,
        googleId,
        authProvider: "google",
        role: "buyer",
        status: "active",
      });

      await user.save();
      isNewUser = true;
    }

    const authTokens = await tokenService.generateAuthTokens(user, {
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    });

    return res.status(isNewUser ? 201 : 200).json({
      message: isNewUser
        ? "Buyer registered successfully with Google"
        : "Google login successful",
      accessToken: authTokens.accessToken,
      refreshToken: authTokens.refreshToken,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        status: user.status,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    // This catches database, token-generation, and other unexpected failures.
    console.error("Google buyer controller failed:", error);

    return res.status(500).json({
      message: "Google signup/login failed due to a server error",
    });
  }
};

const registerBuyer = async (req, res) => {
  const { name, email, password } = req.body;

  try {
    const nameError = validateName(name);
    if (nameError) {
      return res.status(400).json({ message: nameError });
    }

    const emailError = validateEmail(email);
    if (emailError) {
      return res.status(400).json({ message: emailError });
    }

    const passwordError = validatePassword(password);
    if (passwordError) {
      return res.status(400).json({ message: passwordError });
    }

    const cleanEmail = email.trim().toLowerCase();

    // Check for duplicate email in MongoDB
    const existingUser = await User.findOne({ email: cleanEmail });
    if (existingUser) {
      return res
        .status(409)
        .json({ message: "User already exists with this email" });
    }

    // Hash passwords using bcryptjs
    const hashPassword = await bcrypt.hash(password, 10);

    // Save the user using the existing Mongoose User model with role BUYER
    const newUser = new User({
      name: name.trim(),
      email: cleanEmail,
      password: hashPassword,
      role: "buyer",
      authProvider: "local",
    });

    await newUser.save();

    return res.status(201).json({
      message: "Buyer registered successfully",
    });
  } catch (error) {
    return res.status(500).json({
      message: "Server error during buyer registration",
      error: error.message,
    });
  }
};

const googleArtist = async (req, res) => {
  const { idToken } = req.body || {};

  if (!idToken || typeof idToken !== "string") {
    return res.status(400).json({
      message: "A valid idToken is required",
    });
  }

  // Verify Google ID token
  let googleUser;

  try {
    googleUser = await verifyGoogleToken(idToken);
  } catch (error) {
    console.error("Google artist token verification failed:", error.message);

    return res.status(401).json({
      message: "Invalid or expired Google token",
      error: error.message,
    });
  }

  const { googleId, email, name } = googleUser;

  try {
    // Find an account using Google ID or email
    let user = await User.findOne({
      $or: [{ googleId }, { email }],
    });

    // Existing account
    if (user) {
      // Reject blocked accounts
      if (
        ["block", "blocked", "blockend", "BLOCKED"].includes(
          String(user.status || "").toLowerCase(),
        )
      ) {
        return res.status(403).json({
          message: "Account is blocked",
        });
      }

      // Do not convert buyer/admin accounts into artist accounts
      const normalizedRole = String(user.role || "").toLowerCase();

      if (normalizedRole !== "artist") {
        return res.status(409).json({
          message: `This email already belongs to a ${normalizedRole || "different"} account. Please use the appropriate login page.`,
        });
      }

      // Prevent linking an account to a different Google identity
      if (user.googleId && user.googleId !== googleId) {
        return res.status(409).json({
          message: "This account is linked to a different Google account",
        });
      }

      // Link an existing artist account to Google if needed
      if (!user.googleId) {
        user.googleId = googleId;
        user.authProvider = "google";
        await user.save();
      }

      // Ensure the artist profile exists
      let artistProfile = await ArtistProfile.findOne({
        user_id: user._id,
      });

      if (!artistProfile) {
        artistProfile = new ArtistProfile({
          user_id: user._id,
          verified: false,
        });

        await artistProfile.save();
      }

      // Generate authentication tokens
      const authTokens = await tokenService.generateAuthTokens(user, {
        ipAddress: req.ip,
        userAgent: req.headers["user-agent"],
      });

      return res.status(200).json({
        message: "Artist Google login successful",
        accessToken: authTokens.accessToken,
        refreshToken: authTokens.refreshToken,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          status: user.status,
        },
      });
    }

    // Create a new artist account
    const newUser = new User({
      name,
      email,
      googleId,
      authProvider: "google",
      role: "artist",
      status: "active",
    });

    await newUser.save();

    // Create the associated artist profile
    const newArtistProfile = new ArtistProfile({
      user_id: newUser._id,
      verified: false,
    });

    await newArtistProfile.save();

    // Generate authentication tokens
    const authTokens = await tokenService.generateAuthTokens(newUser, {
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    });

    return res.status(201).json({
      message: "Artist registered successfully with Google",
      accessToken: authTokens.accessToken,
      refreshToken: authTokens.refreshToken,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        status: newUser.status,
        createdAt: newUser.createdAt,
      },
      artistProfile: {
        id: newArtistProfile._id,
        user_id: newArtistProfile.user_id,
        verified: newArtistProfile.verified,
      },
    });
  } catch (error) {
    console.error("Google artist authentication failed:", error);

    return res.status(500).json({
      message: "Server error during Google artist authentication",
    });
  }
};

const signupArtist = async (req, res) => {
  const { name, studioName, email, password, specialty, portfolio_url } =
    req.body;
  try {
    const nameError = validateName(name);

    if (nameError) {
      return res.status(400).json({ message: nameError });
    }

    const emailError = validateEmail(email);

    if (emailError) {
      return res.status(400).json({ message: emailError });
    }

    const passwrodError = validatePassword(password);

    if (passwrodError) {
      return res.status(400).json({ message: passwrodError });
    }

    const studioNameError = validateStudioName(studioName);

    if (studioNameError) {
      return res.status(400).json({ message: studioNameError });
    }

    const cleanEmail = email.trim().toLowerCase();

    const existUser = await User.findOne({ email: cleanEmail });

    if (existUser) {
      return res.status(400).json({ message: "User Already Exist" });
    }

    const hashPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      name,
      email: cleanEmail,
      password: hashPassword,
      role: "artist",
    });

    await newUser.save();

    const newArtistProfile = await ArtistProfile({
      user_id: newUser._id,
      studio_name: studioName,
      specialty,
      portfolio_url,
    });

    await newArtistProfile.save();

    res.status(200).json({ message: "User Created" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const signupAdmin = async (req, res) => {
  const { name, email, password, role } = req.body;

  try {
    const nameError = validateName(name);

    if (nameError) {
      return res.status(400).json({ message: nameError });
    }

    const emailError = validateEmail(email);

    if (emailError) {
      return res.status(400).json({ message: emailError });
    }

    const passwrodError = validatePassword(password);

    if (passwrodError) {
      return res.status(400).json({ message: passwrodError });
    }

    const existUser = await User.findOne({ email });

    if (existUser) {
      return res.status(400).json({ message: "User Already Exist" });
    }

    const hashPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      name,
      email,
      password: hashPassword,
      role: "admin",
    });

    await newUser.save();

    res.status(200).json({ message: "User Created" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const emailError = validateEmail(email);

    if (emailError) {
      return res.status(400).json({ message: emailError });
    }

    const passwrodError = validatePassword(password);

    if (passwrodError) {
      return res.status(400).json({ message: passwrodError });
    }

    const existEmail = await User.findOne({ email });

    if (!existEmail) {
      return res.status(400).json({ message: "User Not Found" });
    }

    const decryptPassword = await bcrypt.compare(password, existEmail.password);

    if (!decryptPassword) {
      return res.status(400).json({ message: "Incorrect Email and Password" });
    }

    const token = jsonwebtoken.sign({ userId: existEmail._id }, jwt, {
      expiresIn: "2d",
    });

    res.status(200).json({
      message: "Login Successfully",
      token,
      user: {
        userId: existEmail._id,
        name: existEmail.name,
        email: existEmail.email,
        role: existEmail.role,
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const logout = async (req, res) => {
  const token = req.body?.refreshToken || req.headers["x-refresh-token"];

  const allDevices = Boolean(req.body?.allDevices);

  try {
    if (token) {
      await tokenService.revokeRefreshToken({ refreshToken: token });
    }

    if (allDevices && req.headers.authorization) {
      try {
        const authHeader = req.headers.authorization;
        const bearerToken = authHeader.startsWith("Bearer ")
          ? authHeader.split(" ")[1]
          : authHeader;
        const decoded = verifyAccessToken(bearerToken);
        if (decoded && decoded.userId) {
          await tokenService.revokeAllUserTokens({ userId: decoded.userId });
        }
      } catch (e) {
        // Ignore invalid token during logout
      }
    }

    return res.status(200).json({
      message: "Logged out successfully",
    });
  } catch (error) {
    return res.status(500).json({
      message: "Server error during logout",
      error: error.message,
    });
  }
};

module.exports = {
  signupArtist,
  login,
  signupAdmin,
  registerBuyer,
  googleBuyer,
  googleArtist,
};
