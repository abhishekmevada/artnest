const { sign } = require("jsonwebtoken");
const {
  User,
  Artwork,
  Order,
  CustomArtwork,
  ArtistProfile,
} = require("../../db/db");

//get artist and artwork info for show in admin page for artist section
const artist_artwork_info = async (req, res) => {
  try {
    const userId = req.user.userId;

    // 1. Verify the logged-in user
    const findUser = await User.findById(userId);

    if (!findUser) {
      return res.status(404).json({
        message: "User Not Found",
      });
    }

    // 2. Find all users whose role is artist
    const artists = await User.find({
      role: "artist",
    })
      .select("_id name status")
      .lean();

    // Return an empty array if no artists exist
    if (artists.length === 0) {
      return res.status(200).json({
        message: "Done",
        totalArtists: 0,
        totalArtworks: 0,
        artists: [],
      });
    }

    // 3. Get the user IDs
    const artistUserIds = artists.map((artist) => artist._id);

    // 4. Find profiles belonging to those users
    const profiles = await ArtistProfile.find({
      user_id: { $in: artistUserIds },
    })
      .select("_id user_id location specialty rating_avg")
      .lean();

    // 5. Map profiles using their associated user ID
    const profileMap = new Map();

    profiles.forEach((profile) => {
      profileMap.set(profile.user_id.toString(), profile);
    });

    // 6. Get all artist profile IDs
    // const profileIds = profiles.map((profile) => profile._id);

    // console.log("Artist User IDs:", artistUserIds);

    // console.log(
    //   "Artist Profile IDs:",
    //   profiles.map((profile) => profile._id),
    // );

    const allArtworks = await Artwork.find().select("title artist_id").lean();

    // console.log("Artwork records:", allArtworks);

    // 7. Count artworks belonging to each artist profile
    const artworkCounts = await Artwork.aggregate([
      {
        $match: {
          artist_id: { $in: artistUserIds },
        },
      },
      {
        $group: {
          _id: "$artist_id",
          totalArtworks: { $sum: 1 },
        },
      },
    ]);

    // 8. Map artwork counts using artist profile ID
    const artworkCountMap = new Map();

    artworkCounts.forEach((item) => {
      artworkCountMap.set(item._id.toString(), item.totalArtworks);
    });

    // 9. Build the final artist summary
    const artistList = artists.map((artist) => {
      const profile = profileMap.get(artist._id.toString());

      const artworkCount = artworkCountMap.get(artist._id.toString()) || 0;

      return {
        artistId: artist._id,
        name: artist.name,

        specialty: profile?.specialty || null,

        location: profile?.location || "Not specified",

        artworks: artworkCount,

        // Replace this placeholder when sales data is available.
        sales: 0,

        rating: profile?.rating_avg ?? 0,

        status: artist.status,
      };
    });

    // 10. Calculate total artworks across all artists
    const totalArtworks = artistList.reduce(
      (total, artist) => total + artist.artworks,
      0,
    );

    // 11. Send response
    return res.status(200).json({
      message: "Artist information fetched successfully",
      totalArtists: artistList.length,
      totalArtworks,
      artists: artistList,
    });
  } catch (error) {
    console.error("Artist artwork information error:", error);

    return res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const activeStatusArtist = async (req, res) => {
  const artistId = req.params.id;
  const userId = req.user.userId;

  try {
    const findArtist = await User.findById(artistId);

    if (!findArtist) {
      return res.status(400).json({ message: "User Not Found" });
    }

    if (userId.role === "artist" || userId.role === "buyer") {
      return res
        .status(400)
        .json({ message: "You have no Authority to Access it" });
    }

    findArtist.status = "active";
    await findArtist.save();
    res.status(200).json({ message: "Status Updated" });
  } catch (error) {
    return res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const blockStatusArtist = async (req, res) => {
  const artistId = req.params.id;
  const userId = req.user.userId;

  try {
    const findArtist = await User.findById(artistId);

    if (!findArtist) {
      return res.status(400).json({ message: "User Not Found" });
    }

    if (userId.role === "artist" || userId.role === "buyer") {
      return res
        .status(400)
        .json({ message: "You have no Authority to Access it" });
    }

    findArtist.status = "block";
    await findArtist.save();
    res.status(200).json({ message: "Status Updated" });
  } catch (error) {
    return res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

//get all artwork for show in admin page for artwork section
const getAllArtwork = async (req, res) => {
  try {
    const getAllArtwork = await Artwork.find();

    res.status(200).json({ message: "All Artwork", getAllArtwork });
  } catch (error) {
    return res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const updateArtwork = async (req, res) => {
  const { title, category, status, medium, price } = req.body;
  const artworkId = req.params.id;

  try {
    if (!title || !category || !status || !price || !medium) {
      return res.status(400).json({ message: "Please Fill The Fields" });
    }

    const findArtwork = await Artwork.findById(artworkId);

    if (!findArtwork) {
      return res.status(400).json({ message: "Artwork Not Found" });
    }

    findArtwork.title = title;
    findArtwork.category = category;
    findArtwork.status = status;
    findArtwork.medium = medium;
    findArtwork.price = price;

    await findArtwork.save();

    res.status(200).json({ message: "Artwork Updated" });
  } catch (error) {
    return res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const approveArtwork = async (req, res) => {
  const artworkId = req.params.id;
  const userId = req.user.userId;

  try {
    const findArtworkId = await Artwork.findById(artworkId);

    if (!findArtworkId) {
      return res.status(400).json({ message: "Artwork Not Found" });
    }

    const findUserId = await User.findById({ _id: userId, role: "admin" });

    if (!findUserId) {
      return res.status(400).json({ message: "User Not Found" });
    }

    findArtworkId.moderation_status = "approved";
    await findArtworkId.save();
    res.status(200).json({ message: "Artwork Approved" });
  } catch (error) {
    res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const rejectArtwork = async (req, res) => {
  const artworkId = req.params.id;
  const userId = req.user.userId;

  try {
    const findArtworkId = await Artwork.findById(artworkId);

    if (!findArtworkId) {
      return res.status(400).json({ message: "Artwork Not Found" });
    }

    const findUserId = await User.findById({ _id: userId, role: "admin" });

    if (!findUserId) {
      return res.status(400).json({ message: "User Not Found" });
    }

    findArtworkId.moderation_status = "rejected";
    await findArtworkId.save();
    res.status(200).json({ message: "Artwork Rejected" });
  } catch (error) {
    res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const getOrders = async (req, res) => {
  const userId = req.user.userId;

  try {
    const checkUser = await User.findById(userId);

    if (!checkUser) {
      return res.status(400).json({ message: "User Not Found" });
    }

    const listOrders = await Order.find()
      .select(
        "orderId name total placed_at orderItems.artworkId status phonenumber address city state pincode country",
      )
      .populate({
        path: "orderItems.artworkId",
        select: "title artist_id",
        populate: { path: "artist_id", select: "name" },
      });

    res.status(200).json({ message: "List Of Orders ", listOrders });
  } catch (error) {
    res.status(500).json({
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

const getCustomArtWork = async (req, res) => {
  const userId = req.user.userId;

  try {
    const findUser = await User.findOne({ _id: userId, role: "admin" });

    if (!findUser) {
      return res.status(400).json({ message: "User Not Found" });
    }

    const getCustomArtwork = await CustomArtwork.find()
      .select(
        "customArtworkId name typeofArtwork preferedArtist budge neededDate status",
      )
      .populate({ path: "preferedArtist", select: "name" });

    res.status(200).json({ message: "List of Artwork", getCustomArtwork });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const getBuyers = async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(
      100,
      Math.max(1, parseInt(req.query.limit, 10) || 10),
    );
    const skip = (page - 1) * limit;

    // Filter by buyer role (handles both 'BUYER' and 'buyer')
    const query = { role: { $in: ["BUYER", "buyer"] } };

    // Support optional name/email search
    const searchTerm = req.query.search || req.query.name || req.query.email;
    if (searchTerm && typeof searchTerm === "string" && searchTerm.trim()) {
      const searchRegex = new RegExp(searchTerm.trim(), "i");
      query.$or = [{ name: searchRegex }, { email: searchRegex }];
    }

    // Exclude password hashes, Google tokens, and other sensitive fields
    const [totalBuyers, buyers] = await Promise.all([
      User.countDocuments(query),
      User.find(query)
        .select("_id name email status role createdAt")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
    ]);

    const formattedBuyers = buyers.map((buyer) => ({
      id: buyer._id,
      name: buyer.name,
      email: buyer.email,
      status: buyer.status,
      role: buyer.role,
      createdAt: buyer.createdAt,
    }));

    return res.status(200).json({
      message: "Buyers retrieved successfully",
      buyers: formattedBuyers,
      pagination: {
        totalBuyers,
        page,
        limit,
        totalPages: Math.ceil(totalBuyers / limit) || 0,
      },
    });
  } catch (error) {
    return res.status(500).json({
      message: "Server error fetching buyers",
      error: error.message,
    });
  }
};

const adminOverview = async (req, res) => {
  try {
    // Optional year query: /admin/overview?year=2026
    const currentYear = new Date().getFullYear();
    const requestedYear = Number(req.query.year || currentYear);

    if (
      !Number.isInteger(requestedYear) ||
      requestedYear < 2000 ||
      requestedYear > 9999
    ) {
      return res.status(400).json({
        message: "Please provide a valid year",
      });
    }

    // Selected year's date range
    const startOfYear = new Date(requestedYear, 0, 1);
    const startOfNextYear = new Date(requestedYear + 1, 0, 1);

    // All 12 months in order
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];

    // All artwork categories, including categories with no sales
    const artworkCategories = [
      "paintings",
      "sculptures",
      "ceramics",
      "photography",
      "digital",
      "textile",
      "printmaking",
    ];

    const [
      totalRevenueResult,
      monthlyRevenueResult,
      totalOrders,
      pendingOrders,
      totalArtists,
      monthlyArtistsResult,
      totalArtwork,
      customArtRequests,
      monthlyOrdersResult,
      categoryResult,
    ] = await Promise.all([
      // 1. All-time total revenue from paid orders
      Order.aggregate([
        {
          $match: {
            payment_status: "paid",
          },
        },
        {
          $group: {
            _id: null,
            totalRevenue: {
              $sum: "$total",
            },
          },
        },
      ]),

      // 2. Monthly revenue for the selected year
      Order.aggregate([
        {
          $match: {
            payment_status: "paid",
            placed_at: {
              $gte: startOfYear,
              $lt: startOfNextYear,
            },
          },
        },
        {
          $group: {
            _id: {
              $month: "$placed_at",
            },
            revenue: {
              $sum: "$total",
            },
          },
        },
        {
          $sort: {
            _id: 1,
          },
        },
      ]),

      // 3. Total number of orders
      Order.countDocuments(),

      // 4. Orders that have not yet been delivered or cancelled
      Order.countDocuments({
        status: {
          $nin: ["delivered", "cancle"],
        },
      }),

      // 5. Total artists
      User.countDocuments({
        role: "artist",
      }),

      // 6. Number of artists registered in each month
      User.aggregate([
        {
          $match: {
            role: "artist",
            createdAt: {
              $gte: startOfYear,
              $lt: startOfNextYear,
            },
          },
        },
        {
          $group: {
            _id: {
              $month: "$createdAt",
            },
            artists: {
              $sum: 1,
            },
          },
        },
        {
          $sort: {
            _id: 1,
          },
        },
      ]),

      // 7. Total artwork count
      Artwork.countDocuments(),

      // 8. Custom artwork requests awaiting action
      CustomArtwork.countDocuments({
        status: "placed",
      }),

      // 9. Number of orders placed in each month
      Order.aggregate([
        {
          $match: {
            placed_at: {
              $gte: startOfYear,
              $lt: startOfNextYear,
            },
          },
        },
        {
          $group: {
            _id: {
              $month: "$placed_at",
            },
            orders: {
              $sum: 1,
            },
          },
        },
        {
          $sort: {
            _id: 1,
          },
        },
      ]),

      // 10. Sales by category for paid orders in the selected year
      Order.aggregate([
        {
          $match: {
            payment_status: "paid",
            placed_at: {
              $gte: startOfYear,
              $lt: startOfNextYear,
            },
          },
        },
        {
          $unwind: "$orderItems",
        },
        {
          $lookup: {
            from: "artworks",
            localField: "orderItems.artworkId",
            foreignField: "_id",
            as: "artwork",
          },
        },
        {
          $unwind: "$artwork",
        },
        {
          $group: {
            _id: "$artwork.category",
            totalSold: {
              $sum: 1,
            },
            salesRevenue: {
              $sum: "$artwork.price",
            },
          },
        },
        {
          $sort: {
            salesRevenue: -1,
          },
        },
      ]),
    ]);

    // ----------------------------------------
    // MONTHLY REVENUE: JANUARY TO DECEMBER
    // ----------------------------------------

    const monthlyRevenueMap = new Map(
      monthlyRevenueResult.map((item) => [item._id, item.revenue]),
    );

    const monthlyRevenue = monthNames.map((month, index) => ({
      month,
      monthNumber: index + 1,
      revenue: monthlyRevenueMap.get(index + 1) || 0,
    }));

    // ----------------------------------------
    // MONTHLY ORDERS: JANUARY TO DECEMBER
    // ----------------------------------------

    const monthlyOrdersMap = new Map(
      monthlyOrdersResult.map((item) => [item._id, item.orders]),
    );

    const monthlyOrders = monthNames.map((month, index) => ({
      month,
      monthNumber: index + 1,
      orders: monthlyOrdersMap.get(index + 1) || 0,
    }));

    // ----------------------------------------
    // MONTHLY ARTISTS: JANUARY TO DECEMBER
    // ----------------------------------------

    const monthlyArtistsMap = new Map(
      monthlyArtistsResult.map((item) => [item._id, item.artists]),
    );

    const monthlyArtists = monthNames.map((month, index) => ({
      month,
      monthNumber: index + 1,
      artists: monthlyArtistsMap.get(index + 1) || 0,
    }));

    const totalMonthlyArtists = monthlyArtists.reduce(
      (sum, item) => sum + item.artists,
      0,
    );

    // ----------------------------------------
    // SALES BY CATEGORY: INCLUDE ZERO-SALE CATEGORIES
    // ----------------------------------------

    const categoryMap = new Map(categoryResult.map((item) => [item._id, item]));

    const totalCategoryRevenue = categoryResult.reduce(
      (sum, item) => sum + item.salesRevenue,
      0,
    );

    const salesByCategory = artworkCategories.map((category) => {
      const item = categoryMap.get(category);

      const totalSold = item?.totalSold || 0;
      const salesRevenue = item?.salesRevenue || 0;

      const percentage =
        totalCategoryRevenue > 0
          ? Number(((salesRevenue / totalCategoryRevenue) * 100).toFixed(2))
          : 0;

      return {
        category,
        totalSold,
        salesRevenue,
        percentage,
      };
    });

    // ----------------------------------------
    // FINAL RESPONSE
    // ----------------------------------------

    return res.status(200).json({
      message: "Admin dashboard data fetched successfully",

      overview: {
        totalRevenue: totalRevenueResult[0]?.totalRevenue || 0,
        totalOrders,
        totalArtists,
        totalArtwork,
        pendingOrders,
        customArtRequests,
      },

      monthlyRevenue: {
        year: requestedYear,
        data: monthlyRevenue,
      },

      monthlyOrders: {
        year: requestedYear,
        data: monthlyOrders,
      },

      monthlyArtists: {
        year: requestedYear,
        total: totalMonthlyArtists,
        data: monthlyArtists,
      },

      salesByCategory: {
        year: requestedYear,
        totalCategoryRevenue,
        data: salesByCategory,
      },
    });
  } catch (error) {
    console.error("Admin Overview Error:", error);

    return res.status(500).json({
      message: "Failed to fetch admin dashboard data",
      error: error.message,
    });
  }
};

module.exports = {
  artist_artwork_info,
  activeStatusArtist,
  blockStatusArtist,
  getAllArtwork,
  updateArtwork,
  approveArtwork,
  rejectArtwork,
  getBuyers,
  getOrders,
  getCustomArtWork,
  adminOverview,
};
