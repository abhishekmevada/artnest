const express = require("express");
const {
  getAllArtwork,
  getAllArtist,
  newsletterSub,
} = require("../controllers/guest.controller");

const routes = express.Router();

routes.get("/get-all-artwork", getAllArtwork);
routes.get("/get-all-artist", getAllArtist);
routes.post("/subscribe", newsletterSub);

module.exports = routes;
