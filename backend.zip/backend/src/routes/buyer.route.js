const express = require("express");
const autiMiddleware = require("../middlewares/middleware");
const {
  createOder,
  cutomArtworkCreate,
  addItemtoWislist,
  getWishlist,
  removeItemtoWishlist,
  addItemtoCart,
  removeItemtoCart,
  removeallItemCart,
  getOrders,
  createMessage,
  conversationMessage,
  getConversations,
  getConversationId,
} = require("../controllers/buyer.controller");
const { Customupload } = require("../middlewares/uploadMiddleware");

const router = express.Router();

router.post(
  "/create-order",
  autiMiddleware,
  Customupload.array("image", 4),
  createOder,
);
router.post("/create-custom-artwork", autiMiddleware, cutomArtworkCreate);
router.post("/wishlist-item/:id", autiMiddleware, addItemtoWislist);
router.get("/get-wishlist-item", autiMiddleware, getWishlist);
router.delete(
  "/remove-wishlist-item/:id",
  autiMiddleware,
  removeItemtoWishlist,
);
router.post("/cart/:id", autiMiddleware, addItemtoCart);
router.delete("/remove-cart/:id", autiMiddleware, removeItemtoCart);
router.delete("/remove-all-cart/:id", autiMiddleware, removeallItemCart);
router.get("/get-orders", autiMiddleware, getOrders);
router.post("/create-message", autiMiddleware, createMessage);
router.post("/conversation/:id", autiMiddleware, conversationMessage);
router.get("/conversation", autiMiddleware, getConversations);
router.get("/conversation/:id", autiMiddleware, getConversationId);

module.exports = router;
