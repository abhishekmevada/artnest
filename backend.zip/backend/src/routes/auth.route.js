const express = require("express");
const {
  signupArtist,
  login,
  signupAdmin,
  registerBuyer,
  googleBuyer,
  googleArtist,
} = require("../controllers/auth.controller");
const router = express.Router();

router.post("/artist_signup", signupArtist);
router.post("/login", login);
router.post("/admin_signup", signupAdmin);
router.post("/buyer_signup", registerBuyer);
router.post("/google/buyer", googleBuyer);
router.post("/google/artist", googleArtist);

module.exports = router;
