const express = require("express");
const authMiddleware = require("../middlewares/middleware");
const reviewController = require("../controllers/review.controller");
const autiMiddleware = require("../middlewares/middleware");

const router = express.Router();

router.post(
  "/create-review/:id",
  authMiddleware,
  reviewController.create_review,
);

router.post("/:id/reply", authMiddleware, reviewController.reply_to_review);
router.get("/get-all-review", autiMiddleware, reviewController.getAllreviews);

router.get("/:artworkId", reviewController.get_reviews);

module.exports = router;
